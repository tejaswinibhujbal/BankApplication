package project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.dao.ProjectImp;
import project.dao.ProjectInterface;
import project.model.UserRegister;

@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public RegisterController() {
		super();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mobNoStr = request.getParameter("mobNo");
		if(mobNoStr!= null && mobNoStr.length() == 10 && mobNoStr.matches("\\d+")) {
			
			long mobNo = Long.parseLong(mobNoStr);	
			String uName=request.getParameter("uName");
			String password=request.getParameter("password");
			int accNo=Integer.parseInt(request.getParameter("accNo"));
			float accBal=Float.parseFloat(request.getParameter("accBal"));

			UserRegister uobj=new UserRegister(mobNo, uName, password, accNo, accBal);
			List<UserRegister> ulst=new ArrayList<UserRegister>();
			ulst.add(uobj);
			HttpSession session=request.getSession();
			session.setAttribute("regData", ulst);
			
			for(UserRegister r:ulst) {
				System.out.println(r.getAccNo());
			}
			ProjectInterface pobj=new ProjectImp();
			int i=pobj.createRecord(ulst);
			if(i>0) {
				response.sendRedirect("LoginView.jsp");
			}
		}else {
			response.sendRedirect("Error.jsp");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
