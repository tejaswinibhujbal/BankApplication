package project.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.dao.ProjectImp;
import project.dao.ProjectInterface;
import project.model.Neft;
import project.model.Recharge;

@WebServlet("/NeftController")
public class NeftController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public NeftController() {
		super();	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
		System.out.println("Test");
		int accNo =Integer.parseInt(request.getParameter("accNo")); 
		String bName = request.getParameter("bName"); 
		System.out.println("Test1"); 
		int bAccNo =Integer.parseInt(request.getParameter("bAccNo")); 

		float tamt = Float.parseFloat(request.getParameter("tamt")); 


		Neft nobj = new Neft(accNo, bName, bAccNo, tamt);
		System.out.println("Test3"); 
		List<Neft> nlst = new ArrayList<Neft>();
		nlst.add(nobj); 

		/*
		 * Neft vneft=new Neft(); vneft.setAccNo(accNo); vneft.setTamt(tamt);
		 */
		ProjectImp obj=new ProjectImp();
		boolean b=obj.validateNeft(nobj);
		if(b) {
			
			ProjectInterface pobj = new ProjectImp(); 

			int i = pobj.neftRecord(nlst); 
			System.out.println("value of i:"+i);

			if(i > 0)
			{ 
				System.out.println("Test6");
				HttpSession session=request.getSession(true);
				System.out.println("Session ID: " + session.getId());
				System.out.println("test7");
				session.setAttribute("data", nlst);
				System.out.println("test8");
				
				response.sendRedirect("NeftConfirm.jsp");
			} 
			else {
				response.sendRedirect("Error.jsp"); } 
		}
		else {
			response.sendRedirect("Error.jsp");
		}

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
