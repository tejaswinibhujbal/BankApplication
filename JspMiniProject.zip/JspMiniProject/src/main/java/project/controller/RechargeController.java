package project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import project.dao.ProjectImp;
import project.dao.ProjectInterface;
import project.model.Login;
import project.model.Recharge;
import project.model.UserRegister;

@WebServlet("/RechargeController")
public class RechargeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	List<Recharge> lst=null;
	@Override
	public void init() throws ServletException {
		lst=new ArrayList<Recharge>();

	}

	public RechargeController() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mobNoStr = request.getParameter("mobNo");
		if (mobNoStr != null && mobNoStr.length() == 10 && mobNoStr.matches("\\d+")) {
			Long mobNo = Long.parseLong(mobNoStr);
			String service = request.getParameter("service");
			Integer accNo = Integer.parseInt(request.getParameter("accNo"));
			Float amt = Float.parseFloat(request.getParameter("amt"));
			Recharge robj1 = new Recharge(mobNo, service, accNo, amt);
			Recharge robj=new Recharge();
			robj.setMobNo(mobNo);
			robj.setAccNo(accNo);	
			lst.add(robj1);
			HttpSession session=request.getSession();
			ProjectImp obj=new ProjectImp();
			System.out.println("test4.1");

			boolean b=obj.validateRecharge(robj);
			System.out.println("test4");
			System.out.println(b);
			if(b==true) {
				
				ProjectInterface pobj = new ProjectImp();
				int result = pobj.doRecharge(lst);
				System.out.println("test5");

				if (result > 0) {
					session.setAttribute("rechargeData", lst);
					response.sendRedirect("ConfirmDetails.jsp");
					System.out.println("test6");

				} else {
					response.sendRedirect("Error.jsp");
				}
			}else {
				response.sendRedirect("Error.jsp");
			}
		}

	} 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
