package project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.dao.ProjectImp;
import project.dao.ProjectInterface;
import project.model.Payment;
import project.model.Recharge;

/**
 * Servlet implementation class PaymentController
 */
@WebServlet("/PaymentController")
public class PaymentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public PaymentController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			 
		System.out.println("test1");
		 List<Recharge> rlst= new ArrayList<Recharge>();

			System.out.println("test2");
			
		 HttpSession session = request.getSession(true);
		 System.out.println("TT1 "+ session==null);
	//	 if (session != null && session.getAttribute("rechargeData") != null) {

			 rlst=(List<Recharge>)session.getAttribute("rechargeData");
			 System.out.println("TT2");
			 //System.out.println("hello : "+r.getAmt());
			 Recharge r=rlst.get(0);
			 System.out.println("hello : "+r.getAmt());
			 ProjectInterface pobj=new ProjectImp();
				System.out.println("test3");
				
			 int i=pobj.updateRecord(rlst);
				 System.out.println(i);

					System.out.println("test4");
					
				 if (i > 0) {
						response.sendRedirect("RechargeDone.jsp");
			            
				 }   else {
			            response.sendRedirect("TransactionFailed.jsp");
			        }
		 }
				 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
